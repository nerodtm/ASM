"""SQLite persistence layer for the ASM tool.

Kept intentionally small: three tables (targets, assets, scans) and a handful
of helpers. The interesting bit is `upsert_asset`, which decides whether a
discovered asset is *new* (never seen before) and flags it accordingly.
"""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable

DB_PATH = os.environ.get("ASM_DB_PATH", os.path.join("data", "asm.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS groups (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT UNIQUE NOT NULL,
    color       TEXT,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS targets (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT,
    value           TEXT UNIQUE NOT NULL,      -- domain or IP you onboard
    enabled         INTEGER NOT NULL DEFAULT 1,
    added_at        TEXT NOT NULL,
    last_scan_at    TEXT,
    last_status     TEXT DEFAULT 'pending',    -- pending | scanning | ok | error
    enumerate_subs  INTEGER NOT NULL DEFAULT 1,-- run subdomain discovery on scan
    parent_id       INTEGER,                   -- set when auto-added from a parent
    source          TEXT NOT NULL DEFAULT 'manual',  -- manual | subdomain
    scan_mode       TEXT NOT NULL DEFAULT 'passive', -- passive | light | aggressive
    group_id        INTEGER                    -- folder / group membership
);

CREATE TABLE IF NOT EXISTS assets (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id     INTEGER NOT NULL,
    kind          TEXT NOT NULL,             -- host | port | tech | endpoint
    akey          TEXT NOT NULL,             -- stable identity for de-dup
    label         TEXT NOT NULL,             -- human-readable summary
    details       TEXT,                      -- JSON blob
    first_seen    TEXT NOT NULL,
    last_seen     TEXT NOT NULL,
    is_new        INTEGER NOT NULL DEFAULT 1,
    acknowledged  INTEGER NOT NULL DEFAULT 0,
    status        TEXT NOT NULL DEFAULT 'active',   -- active | gone
    UNIQUE(target_id, kind, akey),
    FOREIGN KEY(target_id) REFERENCES targets(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS scans (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id   INTEGER NOT NULL,
    started_at  TEXT NOT NULL,
    finished_at TEXT,
    status      TEXT NOT NULL DEFAULT 'running',
    new_count   INTEGER DEFAULT 0,
    gone_count  INTEGER DEFAULT 0,
    summary     TEXT,
    FOREIGN KEY(target_id) REFERENCES targets(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_assets_target ON assets(target_id);
CREATE INDEX IF NOT EXISTS idx_assets_new ON assets(is_new);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS users (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    username       TEXT UNIQUE NOT NULL,
    pw_hash        TEXT NOT NULL,
    role           TEXT NOT NULL DEFAULT 'user',
    must_change_pw INTEGER NOT NULL DEFAULT 0,
    disabled       INTEGER NOT NULL DEFAULT 0,
    created_at     TEXT NOT NULL,
    last_login_at  TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
    token      TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
"""


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def get_setting(conn: sqlite3.Connection, key: str, default: str | None = None) -> str | None:
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(conn: sqlite3.Connection, key: str, value: str) -> None:
    with conn:
        conn.execute(
            "INSERT INTO settings(key, value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value))


def set_target_mode(conn: sqlite3.Connection, target_id: int, mode: str) -> None:
    with conn:
        conn.execute("UPDATE targets SET scan_mode=? WHERE id=?", (mode, target_id))


def set_all_modes(conn: sqlite3.Connection, mode: str, group_id: int | None = None) -> int:
    """Set scan mode on every target (optionally only within a group). Returns count."""
    with conn:
        if group_id is None:
            cur = conn.execute("UPDATE targets SET scan_mode=?", (mode,))
        else:
            cur = conn.execute("UPDATE targets SET scan_mode=? WHERE group_id=?",
                               (mode, group_id))
        return cur.rowcount


# --- users & sessions (authentication) -------------------------------------

def count_users(conn: sqlite3.Connection) -> int:
    return conn.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]


def create_user(conn: sqlite3.Connection, username: str, pw_hash: str,
                role: str = "user", must_change_pw: int = 0,
                group_id: int | None = None) -> dict:
    with conn:
        cur = conn.execute(
            "INSERT INTO users(username, pw_hash, role, must_change_pw, created_at, group_id) "
            "VALUES(?,?,?,?,?,?)", (username, pw_hash, role, must_change_pw, now(), group_id))
    return get_user(conn, cur.lastrowid)


def get_user(conn: sqlite3.Connection, user_id: int) -> dict | None:
    r = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    return row_to_dict(r) if r else None


def get_user_by_name(conn: sqlite3.Connection, username: str) -> dict | None:
    r = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    return row_to_dict(r) if r else None


def list_users(conn: sqlite3.Connection) -> list[dict]:
    return [row_to_dict(r) for r in conn.execute(
        "SELECT id, username, role, must_change_pw, disabled, created_at, last_login_at, group_id "
        "FROM users ORDER BY username")]


def list_brand_assets(conn: sqlite3.Connection, group_id: int) -> dict:
    """Keywords and reference-logo fingerprints for a group."""
    rows = [row_to_dict(r) for r in conn.execute(
        "SELECT * FROM brand_assets WHERE group_id=? ORDER BY kind, id", (group_id,))]
    return {
        "keywords": [r for r in rows if r["kind"] == "keyword"],
        "logos": [r for r in rows if r["kind"] == "logo"],
    }


def brand_keywords(conn: sqlite3.Connection, group_id: int) -> list[str]:
    return [r["value"] for r in conn.execute(
        "SELECT value FROM brand_assets WHERE group_id=? AND kind='keyword'", (group_id,))]


def brand_logo_hashes(conn: sqlite3.Connection, group_id: int) -> list[dict]:
    return [{"exact_hash": r["exact_hash"], "phash": r["phash"]}
            for r in conn.execute(
                "SELECT exact_hash, phash FROM brand_assets WHERE group_id=? AND kind='logo'",
                (group_id,))]


def add_brand_keyword(conn: sqlite3.Connection, group_id: int, keyword: str) -> dict:
    with conn:
        cur = conn.execute(
            "INSERT INTO brand_assets(group_id, kind, value, created_at) VALUES(?, 'keyword', ?, ?)",
            (group_id, keyword, now()))
    return row_to_dict(conn.execute("SELECT * FROM brand_assets WHERE id=?", (cur.lastrowid,)).fetchone())


def add_brand_logo(conn: sqlite3.Connection, group_id: int, exact_hash: str,
                   phash: str, label: str) -> dict:
    with conn:
        cur = conn.execute(
            "INSERT INTO brand_assets(group_id, kind, exact_hash, phash, label, created_at) "
            "VALUES(?, 'logo', ?, ?, ?, ?)", (group_id, exact_hash, phash, label, now()))
    return row_to_dict(conn.execute("SELECT * FROM brand_assets WHERE id=?", (cur.lastrowid,)).fetchone())


def get_brand_asset(conn: sqlite3.Connection, asset_id: int) -> dict | None:
    r = conn.execute("SELECT * FROM brand_assets WHERE id=?", (asset_id,)).fetchone()
    return row_to_dict(r) if r else None


def delete_brand_asset(conn: sqlite3.Connection, asset_id: int) -> None:
    with conn:
        conn.execute("DELETE FROM brand_assets WHERE id=?", (asset_id,))


def list_vendors(conn: sqlite3.Connection, target_id: int | None = None,
                 group_id: int | None = None) -> list[dict]:
    """Third-party vendors/partners, joined to their domain. Optionally filtered
    to one target or scoped to a group (for multi-tenant members)."""
    sql = ("SELECT v.*, t.value AS target_value, t.group_id AS group_id "
           "FROM vendors v JOIN targets t ON t.id=v.target_id WHERE 1=1")
    args: list[Any] = []
    if target_id is not None:
        sql += " AND v.target_id=?"
        args.append(target_id)
    if group_id is not None:
        sql += " AND t.group_id=?"
        args.append(group_id)
    sql += " ORDER BY t.value, v.name"
    return [row_to_dict(r) for r in conn.execute(sql, args)]


def add_vendor(conn: sqlite3.Connection, target_id: int, name: str,
               role: str | None = None, url: str | None = None,
               notes: str | None = None) -> dict:
    with conn:
        cur = conn.execute(
            "INSERT INTO vendors(target_id, name, role, url, notes, created_at) "
            "VALUES(?,?,?,?,?,?)", (target_id, name, role, url, notes, now()))
    r = conn.execute("SELECT * FROM vendors WHERE id=?", (cur.lastrowid,)).fetchone()
    return row_to_dict(r)


def get_vendor(conn: sqlite3.Connection, vendor_id: int) -> dict | None:
    r = conn.execute("SELECT * FROM vendors WHERE id=?", (vendor_id,)).fetchone()
    return row_to_dict(r) if r else None


def update_vendor(conn: sqlite3.Connection, vendor_id: int, name: str,
                  role: str | None, url: str | None, notes: str | None) -> None:
    with conn:
        conn.execute(
            "UPDATE vendors SET name=?, role=?, url=?, notes=? WHERE id=?",
            (name, role, url, notes, vendor_id))


def delete_vendor(conn: sqlite3.Connection, vendor_id: int) -> None:
    with conn:
        conn.execute("DELETE FROM vendors WHERE id=?", (vendor_id,))


def get_group(conn: sqlite3.Connection, group_id: int) -> dict | None:
    r = conn.execute("SELECT * FROM groups WHERE id=?", (group_id,)).fetchone()
    return row_to_dict(r) if r else None


def set_group_email_domain(conn: sqlite3.Connection, group_id: int, domain: str | None) -> None:
    with conn:
        conn.execute("UPDATE groups SET email_domain=? WHERE id=?", (domain, group_id))


def set_user_password(conn: sqlite3.Connection, user_id: int, pw_hash: str,
                      must_change_pw: int = 0) -> None:
    with conn:
        conn.execute("UPDATE users SET pw_hash=?, must_change_pw=? WHERE id=?",
                     (pw_hash, must_change_pw, user_id))


def set_user_disabled(conn: sqlite3.Connection, user_id: int, disabled: int) -> None:
    with conn:
        conn.execute("UPDATE users SET disabled=? WHERE id=?", (disabled, user_id))
        if disabled:
            conn.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))


def touch_login(conn: sqlite3.Connection, user_id: int) -> None:
    with conn:
        conn.execute("UPDATE users SET last_login_at=? WHERE id=?", (now(), user_id))


def delete_user(conn: sqlite3.Connection, user_id: int) -> None:
    with conn:
        conn.execute("DELETE FROM users WHERE id=?", (user_id,))


def create_session(conn: sqlite3.Connection, token: str, user_id: int,
                   expires_at: str) -> None:
    with conn:
        conn.execute(
            "INSERT INTO sessions(token, user_id, created_at, expires_at) VALUES(?,?,?,?)",
            (token, user_id, now(), expires_at))


def get_session_user(conn: sqlite3.Connection, token: str) -> dict | None:
    """Return the (enabled) user for a still-valid session token, else None."""
    r = conn.execute(
        "SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id "
        "WHERE s.token=? AND s.expires_at > ? AND u.disabled=0",
        (token, now())).fetchone()
    return row_to_dict(r) if r else None


def delete_session(conn: sqlite3.Connection, token: str) -> None:
    with conn:
        conn.execute("DELETE FROM sessions WHERE token=?", (token,))


def prune_sessions(conn: sqlite3.Connection) -> None:
    with conn:
        conn.execute("DELETE FROM sessions WHERE expires_at <= ?", (now(),))


def connect() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    # API and the scanner worker are separate processes sharing this DB. WAL lets
    # readers and one writer run concurrently; busy_timeout makes a brief write
    # collision wait-and-retry instead of erroring.
    conn.execute("PRAGMA busy_timeout = 8000")
    return conn


def init_db() -> None:
    conn = connect()
    with conn:
        conn.executescript(SCHEMA)
        _migrate(conn)
    conn.close()


def _migrate(conn: sqlite3.Connection) -> None:
    """Additive migrations so existing databases pick up new columns."""
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(targets)")}
    additions = {
        "enumerate_subs": "INTEGER NOT NULL DEFAULT 1",
        "parent_id": "INTEGER",
        "source": "TEXT NOT NULL DEFAULT 'manual'",
        "scan_mode": "TEXT NOT NULL DEFAULT 'passive'",
        "group_id": "INTEGER",
    }
    for col, ddl in additions.items():
        if col not in cols:
            conn.execute(f"ALTER TABLE targets ADD COLUMN {col} {ddl}")

    # multi-tenant columns
    ucols = {r["name"] for r in conn.execute("PRAGMA table_info(users)")}
    if "group_id" not in ucols:
        conn.execute("ALTER TABLE users ADD COLUMN group_id INTEGER")
    gcols = {r["name"] for r in conn.execute("PRAGMA table_info(groups)")}
    if "email_domain" not in gcols:
        conn.execute("ALTER TABLE groups ADD COLUMN email_domain TEXT")

    # --- performance indexes -------------------------------------------------
    # These only speed up lookups; they never change query results. Created
    # here (not in SCHEMA) so existing databases pick them up on upgrade.
    for ddl in (
        "CREATE INDEX IF NOT EXISTS idx_assets_kind_status ON assets(kind, status)",
        "CREATE INDEX IF NOT EXISTS idx_assets_target_kind ON assets(target_id, kind, status)",
        "CREATE INDEX IF NOT EXISTS idx_assets_status ON assets(status)",
        "CREATE INDEX IF NOT EXISTS idx_assets_first_seen ON assets(first_seen)",
        "CREATE INDEX IF NOT EXISTS idx_assets_last_seen ON assets(last_seen)",
        "CREATE INDEX IF NOT EXISTS idx_assets_new_ack ON assets(is_new, acknowledged)",
        "CREATE INDEX IF NOT EXISTS idx_targets_group ON targets(group_id)",
        "CREATE INDEX IF NOT EXISTS idx_targets_parent ON targets(parent_id)",
        "CREATE INDEX IF NOT EXISTS idx_scans_target ON scans(target_id)",
    ):
        conn.execute(ddl)

    # third-party vendors / partners per domain (manual records)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS vendors (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            target_id   INTEGER NOT NULL,
            name        TEXT NOT NULL,
            role        TEXT,
            url         TEXT,
            notes       TEXT,
            created_at  TEXT NOT NULL,
            FOREIGN KEY(target_id) REFERENCES targets(id) ON DELETE CASCADE
        )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_vendors_target ON vendors(target_id)")

    # per-group brand assets: keywords + reference-logo hashes for impersonation
    conn.execute("""
        CREATE TABLE IF NOT EXISTS brand_assets (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            group_id    INTEGER NOT NULL,
            kind        TEXT NOT NULL,          -- 'keyword' | 'logo'
            value       TEXT,                   -- keyword text
            exact_hash  TEXT,                   -- logo: md5 of image bytes
            phash       TEXT,                   -- logo: perceptual dhash (hex)
            label       TEXT,                   -- logo: filename for display
            created_at  TEXT NOT NULL,
            FOREIGN KEY(group_id) REFERENCES groups(id) ON DELETE CASCADE
        )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_brand_group ON brand_assets(group_id)")

    # job queue for the separate scanner worker process/container
    conn.execute("""
        CREATE TABLE IF NOT EXISTS scan_jobs (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            target_id   INTEGER NOT NULL,
            status      TEXT NOT NULL DEFAULT 'queued',  -- queued|running|done|error
            reason      TEXT,                            -- manual|scheduled|onboard
            created_at  TEXT NOT NULL,
            started_at  TEXT,
            finished_at TEXT,
            detail      TEXT
        )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_status ON scan_jobs(status, id)")


def row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    d = dict(row)
    if "details" in d and d["details"]:
        try:
            d["details"] = json.loads(d["details"])
        except (json.JSONDecodeError, TypeError):
            pass
    return d


# ---------------------------------------------------------------- targets ---

def add_target(conn: sqlite3.Connection, value: str, name: str | None = None,
               enumerate_subs: bool = True, parent_id: int | None = None,
               source: str = "manual", scan_mode: str = "passive",
               group_id: int | None = None) -> dict:
    value = value.strip().lower()
    with conn:
        conn.execute(
            "INSERT OR IGNORE INTO targets(name, value, added_at, enumerate_subs, "
            "parent_id, source, scan_mode, group_id) VALUES(?,?,?,?,?,?,?,?)",
            (name or value, value, now(), 1 if enumerate_subs else 0, parent_id,
             source, scan_mode, group_id),
        )
    row = conn.execute("SELECT * FROM targets WHERE value=?", (value,)).fetchone()
    return row_to_dict(row)


def get_target_by_value(conn: sqlite3.Connection, value: str) -> dict | None:
    row = conn.execute("SELECT * FROM targets WHERE value=?",
                       (value.strip().lower(),)).fetchone()
    return row_to_dict(row) if row else None


# ------------------------------------------------------------------ groups ---

GROUP_COLORS = ["#3dd6b6", "#6db3ff", "#b58cff", "#ff9e6d", "#f5d76e",
                "#ff6b6b", "#7bd88f", "#c99bff", "#5fb0d4", "#ffb4a2"]


def add_group(conn: sqlite3.Connection, name: str, color: str | None = None) -> dict:
    name = name.strip()
    if not color:
        n = conn.execute("SELECT COUNT(*) FROM groups").fetchone()[0]
        color = GROUP_COLORS[n % len(GROUP_COLORS)]
    with conn:
        conn.execute("INSERT OR IGNORE INTO groups(name, color, created_at) VALUES(?,?,?)",
                     (name, color, now()))
    row = conn.execute("SELECT * FROM groups WHERE name=?", (name,)).fetchone()
    return row_to_dict(row)


def list_groups(conn: sqlite3.Connection) -> list[dict]:
    groups = [row_to_dict(r) for r in
              conn.execute("SELECT * FROM groups ORDER BY name")]
    # attach target + new-finding counts per group
    for g in groups:
        g["targets"] = conn.execute(
            "SELECT COUNT(*) FROM targets WHERE group_id=?", (g["id"],)).fetchone()[0]
        g["new"] = conn.execute(
            "SELECT COUNT(*) FROM assets a JOIN targets t ON t.id=a.target_id "
            "WHERE t.group_id=? AND a.is_new=1 AND a.acknowledged=0", (g["id"],)).fetchone()[0]
    return groups


def rename_group(conn: sqlite3.Connection, group_id: int, name: str | None = None,
                 color: str | None = None) -> None:
    with conn:
        if name is not None:
            conn.execute("UPDATE groups SET name=? WHERE id=?", (name.strip(), group_id))
        if color is not None:
            conn.execute("UPDATE groups SET color=? WHERE id=?", (color, group_id))


def delete_group(conn: sqlite3.Connection, group_id: int) -> None:
    """Delete a group; its targets become ungrouped (targets are NOT removed)."""
    with conn:
        conn.execute("UPDATE targets SET group_id=NULL WHERE group_id=?", (group_id,))
        conn.execute("DELETE FROM groups WHERE id=?", (group_id,))


def set_target_group(conn: sqlite3.Connection, target_id: int,
                     group_id: int | None) -> None:
    """Assign a target (and any subdomains beneath it) to a group."""
    with conn:
        conn.execute("UPDATE targets SET group_id=? WHERE id=? OR parent_id=?",
                     (group_id, target_id, target_id))


def list_targets(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute("SELECT * FROM targets ORDER BY added_at DESC").fetchall()
    return [row_to_dict(r) for r in rows]


def get_target(conn: sqlite3.Connection, target_id: int) -> dict | None:
    row = conn.execute("SELECT * FROM targets WHERE id=?", (target_id,)).fetchone()
    return row_to_dict(row) if row else None


def delete_target(conn: sqlite3.Connection, target_id: int) -> None:
    with conn:
        conn.execute("DELETE FROM targets WHERE id=?", (target_id,))


def set_target_status(conn: sqlite3.Connection, target_id: int, status: str,
                      scanned: bool = False) -> None:
    with conn:
        if scanned:
            conn.execute(
                "UPDATE targets SET last_status=?, last_scan_at=? WHERE id=?",
                (status, now(), target_id),
            )
        else:
            conn.execute(
                "UPDATE targets SET last_status=? WHERE id=?", (status, target_id)
            )


# ----------------------------------------------------------------- assets ---

def upsert_asset(conn: sqlite3.Connection, target_id: int, kind: str, akey: str,
                 label: str, details: dict) -> bool:
    """Insert or refresh an asset. Returns True if this was a *newly* seen asset."""
    ts = now()
    existing = conn.execute(
        "SELECT id FROM assets WHERE target_id=? AND kind=? AND akey=?",
        (target_id, kind, akey),
    ).fetchone()
    with conn:
        if existing:
            conn.execute(
                "UPDATE assets SET last_seen=?, label=?, details=?, status='active' "
                "WHERE id=?",
                (ts, label, json.dumps(details), existing["id"]),
            )
            return False
        conn.execute(
            "INSERT INTO assets(target_id, kind, akey, label, details, first_seen, "
            "last_seen, is_new, status) VALUES(?,?,?,?,?,?,?,1,'active')",
            (target_id, kind, akey, label, json.dumps(details), ts, ts),
        )
        return True


def mark_stale_gone(conn: sqlite3.Connection, target_id: int, scan_start: str) -> int:
    """Anything not touched since the scan started is no longer present."""
    with conn:
        cur = conn.execute(
            "UPDATE assets SET status='gone' WHERE target_id=? AND status='active' "
            "AND last_seen < ?",
            (target_id, scan_start),
        )
        return cur.rowcount


def _asset_filter(conn: sqlite3.Connection, target_id: int | None, kind: str | None,
                  new_only: bool, family: bool, q: str | None,
                  new_hours: int | None, group_id: int | None) -> tuple[str, list]:
    """Build the shared WHERE clause so the count and the page always agree."""
    sql = ""
    args: list[Any] = []
    if group_id is not None:
        sql += " AND t.group_id=?"
        args.append(group_id)
    if target_id is not None:
        if family:
            kids = [r["id"] for r in conn.execute(
                "SELECT id FROM targets WHERE parent_id=?", (target_id,))]
            ids = [target_id, *kids]
            sql += " AND a.target_id IN (%s)" % ",".join("?" * len(ids))
            args.extend(ids)
        else:
            sql += " AND a.target_id=?"
            args.append(target_id)
    if kind:
        sql += " AND a.kind=?"
        args.append(kind)
    if new_only:
        sql += " AND a.is_new=1 AND a.acknowledged=0"
    if new_hours:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=new_hours)).isoformat(timespec="seconds")
        sql += " AND a.first_seen >= ?"
        args.append(cutoff)
    if q:
        like = f"%{q.strip()}%"
        sql += " AND (a.label LIKE ? OR t.value LIKE ? OR a.kind LIKE ? OR a.details LIKE ?)"
        args.extend([like, like, like, like])
    return sql, args


def count_assets(conn: sqlite3.Connection, target_id: int | None = None,
                 kind: str | None = None, new_only: bool = False,
                 family: bool = False, q: str | None = None,
                 new_hours: int | None = None, group_id: int | None = None) -> int:
    where, args = _asset_filter(conn, target_id, kind, new_only, family, q, new_hours, group_id)
    sql = ("SELECT COUNT(*) FROM assets a JOIN targets t ON t.id=a.target_id "
           "WHERE 1=1" + where)
    return conn.execute(sql, args).fetchone()[0]


def list_assets(conn: sqlite3.Connection, target_id: int | None = None,
                kind: str | None = None, new_only: bool = False,
                family: bool = False, q: str | None = None,
                new_hours: int | None = None, group_id: int | None = None,
                limit: int | None = None, offset: int = 0) -> list[dict]:
    where, args = _asset_filter(conn, target_id, kind, new_only, family, q, new_hours, group_id)
    sql = ("SELECT a.*, t.value AS target_value FROM assets a "
           "JOIN targets t ON t.id=a.target_id WHERE 1=1" + where)
    sql += " ORDER BY t.value, a.is_new DESC, a.last_seen DESC"
    if limit is not None:
        sql += " LIMIT ? OFFSET ?"
        args = args + [limit, max(0, offset)]
    rows = conn.execute(sql, args).fetchall()
    return [row_to_dict(r) for r in rows]


def acknowledge_asset(conn: sqlite3.Connection, asset_id: int) -> None:
    with conn:
        conn.execute(
            "UPDATE assets SET acknowledged=1, is_new=0 WHERE id=?", (asset_id,)
        )


def get_asset(conn: sqlite3.Connection, asset_id: int) -> dict | None:
    r = conn.execute("SELECT * FROM assets WHERE id=?", (asset_id,)).fetchone()
    return row_to_dict(r) if r else None


# --- scan job queue (consumed by the separate worker process) ---------------

def enqueue_scan(conn: sqlite3.Connection, target_id: int, reason: str = "manual") -> int:
    """Queue a scan unless one is already queued/running for this target."""
    existing = conn.execute(
        "SELECT id FROM scan_jobs WHERE target_id=? AND status IN ('queued','running')",
        (target_id,)).fetchone()
    if existing:
        return existing["id"]
    with conn:
        cur = conn.execute(
            "INSERT INTO scan_jobs(target_id, status, reason, created_at) "
            "VALUES(?, 'queued', ?, ?)", (target_id, reason, now()))
    return cur.lastrowid


def claim_next_job(conn: sqlite3.Connection) -> dict | None:
    """Atomically claim the oldest queued job (single-writer transaction)."""
    with conn:
        row = conn.execute(
            "SELECT * FROM scan_jobs WHERE status='queued' ORDER BY id LIMIT 1").fetchone()
        if not row:
            return None
        conn.execute("UPDATE scan_jobs SET status='running', started_at=? WHERE id=? AND status='queued'",
                     (now(), row["id"]))
        # confirm we won the claim (in case another worker raced us)
        chk = conn.execute("SELECT status FROM scan_jobs WHERE id=?", (row["id"],)).fetchone()
        if chk["status"] != "running":
            return None
    return row_to_dict(row)


def finish_job(conn: sqlite3.Connection, job_id: int, status: str, detail: str = "") -> None:
    with conn:
        conn.execute("UPDATE scan_jobs SET status=?, finished_at=?, detail=? WHERE id=?",
                     (status, now(), detail[:500], job_id))


def job_queue_stats(conn: sqlite3.Connection) -> dict:
    rows = conn.execute("SELECT status, COUNT(*) c FROM scan_jobs GROUP BY status").fetchall()
    out = {"queued": 0, "running": 0, "done": 0, "error": 0}
    for r in rows:
        out[r["status"]] = r["c"]
    return out


def prune_jobs(conn: sqlite3.Connection, keep_days: int = 7) -> int:
    with conn:
        cur = conn.execute(
            "DELETE FROM scan_jobs WHERE status IN ('done','error') "
            "AND finished_at < datetime('now', ?)", (f"-{keep_days} days",))
        return cur.rowcount


def set_asset_details(conn: sqlite3.Connection, asset_id: int, details: dict) -> None:
    with conn:
        conn.execute("UPDATE assets SET details=? WHERE id=?",
                     (json.dumps(details), asset_id))


def acknowledge_all(conn: sqlite3.Connection, target_id: int | None = None) -> int:
    q = "UPDATE assets SET acknowledged=1, is_new=0 WHERE is_new=1"
    args: list[Any] = []
    if target_id is not None:
        q += " AND target_id=?"
        args.append(target_id)
    with conn:
        cur = conn.execute(q, args)
        return cur.rowcount


# ------------------------------------------------------------------ scans ---

def start_scan(conn: sqlite3.Connection, target_id: int) -> int:
    with conn:
        cur = conn.execute(
            "INSERT INTO scans(target_id, started_at) VALUES(?,?)",
            (target_id, now()),
        )
        return cur.lastrowid


def finish_scan(conn: sqlite3.Connection, scan_id: int, status: str,
                new_count: int, gone_count: int, summary: str) -> None:
    with conn:
        conn.execute(
            "UPDATE scans SET finished_at=?, status=?, new_count=?, gone_count=?, "
            "summary=? WHERE id=?",
            (now(), status, new_count, gone_count, summary, scan_id),
        )


def prune(conn: sqlite3.Connection, days: int) -> dict:
    """Apply data retention. Deletes scan-history rows older than `days`, and
    assets that have been *gone* longer than `days`. Never removes active
    assets (your current surface), whatever their age. days<=0 disables it.
    """
    if not days or days <= 0:
        return {"scans": 0, "assets": 0, "cutoff": None}
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat(timespec="seconds")
    with conn:
        s = conn.execute("DELETE FROM scans WHERE started_at < ?", (cutoff,)).rowcount
        a = conn.execute("DELETE FROM assets WHERE status='gone' AND last_seen < ?",
                         (cutoff,)).rowcount
    return {"scans": s, "assets": a, "cutoff": cutoff}


def recent_scans(conn: sqlite3.Connection, limit: int = 20) -> list[dict]:
    rows = conn.execute(
        "SELECT s.*, t.value AS target_value FROM scans s "
        "JOIN targets t ON t.id=s.target_id ORDER BY s.started_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    return [row_to_dict(r) for r in rows]


def data_version(conn: sqlite3.Connection, group_id: int | None = None) -> dict:
    """A cheap fingerprint of the current data set, used by the dashboard to
    decide whether anything actually changed before re-fetching the (large)
    inventory. Index-backed aggregates only — no row transfer."""
    if group_id is None:
        row = conn.execute(
            "SELECT COUNT(*), MAX(last_seen), SUM(is_new=1 AND acknowledged=0) FROM assets").fetchone()
        tcount = conn.execute("SELECT COUNT(*), MAX(COALESCE(last_scan_at,'')) FROM targets").fetchone()
    else:
        row = conn.execute(
            "SELECT COUNT(*), MAX(last_seen), SUM(is_new=1 AND acknowledged=0) FROM assets "
            "WHERE target_id IN (SELECT id FROM targets WHERE group_id=?)", (group_id,)).fetchone()
        tcount = conn.execute(
            "SELECT COUNT(*), MAX(COALESCE(last_scan_at,'')) FROM targets WHERE group_id=?",
            (group_id,)).fetchone()
    return {"assets": row[0] or 0, "last_seen": row[1] or "", "new": row[2] or 0,
            "targets": tcount[0] or 0, "last_scan": tcount[1] or ""}


def stats(conn: sqlite3.Connection, group_id: int | None = None) -> dict:
    if group_id is None:
        tf, af, params = "", "", {}
    else:
        tf = " WHERE group_id=:g"
        af = " AND target_id IN (SELECT id FROM targets WHERE group_id=:g)"
        params = {"g": group_id}

    def scalar(q: str) -> int:
        return conn.execute(q, params).fetchone()[0]

    return {
        "targets": scalar(f"SELECT COUNT(*) FROM targets{tf}"),
        "assets": scalar(f"SELECT COUNT(*) FROM assets WHERE status='active'{af}"),
        "new": scalar(f"SELECT COUNT(*) FROM assets WHERE is_new=1 AND acknowledged=0{af}"),
        "ports": scalar(f"SELECT COUNT(*) FROM assets WHERE kind='port' AND status='active'{af}"),
        "techs": scalar(f"SELECT COUNT(*) FROM assets WHERE kind='tech' AND status='active'{af}"),
        "endpoints": scalar(f"SELECT COUNT(*) FROM assets WHERE kind='endpoint' AND status='active'{af}"),
        "subdomains": scalar(f"SELECT COUNT(*) FROM assets WHERE kind='subdomain' AND status='active'{af}"),
        "waf": scalar(f"SELECT COUNT(*) FROM assets WHERE kind='waf' AND status='active'{af}"),
        "buckets": scalar(f"SELECT COUNT(*) FROM assets WHERE kind='bucket' AND status='active'{af}"),
        "public_buckets": scalar(
            "SELECT COUNT(*) FROM assets WHERE kind='bucket' AND status='active' "
            "AND details LIKE '%\"public\": true%'" + af),
        "breaches": scalar(f"SELECT COUNT(*) FROM assets WHERE kind='breach' AND status='active'{af}"),
        "vulns": scalar(f"SELECT COUNT(*) FROM assets WHERE kind='vuln' AND status='active'{af}"),
        "lookalikes": scalar("SELECT COUNT(*) FROM assets WHERE kind='lookalike' AND status='active' AND details NOT LIKE '%\"risk\": \"owned\"%'" + af),
        "impersonations": scalar(f"SELECT COUNT(*) FROM assets WHERE kind='impersonation' AND status='active'{af}"),
        "takeovers": scalar(f"SELECT COUNT(*) FROM assets WHERE kind='takeover' AND status='active'{af}"),
        "certs_expiring": scalar("SELECT COUNT(*) FROM assets WHERE kind='cert' AND status='active' AND (details LIKE '%\"expiring_soon\": true%' OR details LIKE '%\"expired\": true%')" + af),
        "risky_ports": scalar("SELECT COUNT(*) FROM assets WHERE kind='port' AND status='active' AND details LIKE '%\"risky\": true%'" + af),
        "new_exposed_24h": scalar("SELECT COUNT(*) FROM assets WHERE kind='port' AND status='active' AND first_seen >= datetime('now','-24 hours')" + af),
    }


def graph(conn: sqlite3.Connection, target_ids: list[int] | None = None,
          group_id: int | None = None) -> dict:
    """Build a node/link mesh of targets and their assets.

    target_ids selects which domains to include (their subdomains are pulled in
    automatically); group_id restricts to a folder; None means every target. IP
    nodes are global (deduped), so subdomains sharing infrastructure connect.
    """
    targets = list_targets(conn)
    tmap = {t["id"]: t for t in targets}
    if group_id is not None:
        scope = {t["id"] for t in targets if t["group_id"] == group_id}
    elif target_ids:
        chosen = set(target_ids)
        scope = set(chosen) | {t["id"] for t in targets if t["parent_id"] in chosen}
    else:
        scope = {t["id"] for t in targets}

    nodes: dict[str, dict] = {}
    links: list[dict] = []

    def add(nid: str, ntype: str, label: str, **meta) -> str:
        if nid not in nodes:
            nodes[nid] = {"id": nid, "type": ntype, "label": label, **meta}
        return nid

    for tid in scope:
        t = tmap[tid]
        ntype = "subdomain" if t.get("source") == "subdomain" else "target"
        add(f"t{tid}", ntype, t["value"], status=t.get("last_status"))
        pid = t.get("parent_id")
        if pid in scope:
            links.append({"source": f"t{pid}", "target": f"t{tid}", "rel": "subdomain"})

    # Fetch every in-scope active asset in ONE query. This replaces an N+1
    # pattern (one list_assets() call per target, plus a get_target_by_value()
    # per subdomain asset) that issued thousands of queries for large meshes.
    scope_list = list(scope)
    assets_by_t: dict[int, list] = {tid: [] for tid in scope}
    if scope_list:
        ph = ",".join("?" * len(scope_list))
        for r in conn.execute(
                f"SELECT * FROM assets WHERE status='active' AND target_id IN ({ph})",
                scope_list):
            a = row_to_dict(r)
            assets_by_t.setdefault(a["target_id"], []).append(a)
    val_to_tid = {t["value"]: t["id"] for t in targets}   # avoids per-asset lookups

    for tid in scope:
        assets = assets_by_t.get(tid, [])
        # global IP nodes first
        for a in assets:
            if a["kind"] == "host":
                ipn = add(f"ip:{a['label']}", "ip", a["label"])
                links.append({"source": f"t{tid}", "target": ipn, "rel": "resolves"})
        for a in assets:
            k = a["kind"]
            if k == "host":
                continue
            d = a.get("details") or {}
            new = bool(a["is_new"] and not a["acknowledged"])
            if k == "subdomain":
                child_tid = val_to_tid.get(a["label"])
                if child_tid and f"t{child_tid}" in nodes:
                    continue  # represented by its own target node already
                nid = add(f"a{a['id']}", "subdomain", a["label"], is_new=new)
                links.append({"source": f"t{tid}", "target": nid, "rel": "subdomain"})
            elif k == "port":
                nid = add(f"a{a['id']}", "port", a["label"], is_new=new)
                ip = d.get("ip")
                src = f"ip:{ip}" if ip and f"ip:{ip}" in nodes else f"t{tid}"
                links.append({"source": src, "target": nid, "rel": "port"})
            else:
                nid = add(f"a{a['id']}", k, a["label"], is_new=new,
                          public=bool(d.get("public")))
                links.append({"source": f"t{tid}", "target": nid, "rel": k})

    return {"nodes": list(nodes.values()), "links": links}


def top_issues(conn: sqlite3.Connection, group_id: int | None = None,
               target_id: int | None = None) -> list[dict]:
    """Prioritised, de-duplicated list of security issues across a scope.
    Derives severity from each finding so clients see what to fix first."""
    # exposed database ports are called out separately (critical-adjacent)
    DB_PORTS = {3306: "MySQL", 5432: "PostgreSQL", 27017: "MongoDB", 6379: "Redis",
                9200: "Elasticsearch", 1433: "MSSQL", 11211: "Memcached",
                5984: "CouchDB", 9042: "Cassandra", 7000: "Cassandra", 5984: "CouchDB",
                26257: "CockroachDB", 8086: "InfluxDB", 9000: "ClickHouse", 2181: "ZooKeeper"}
    OTHER_RISKY = {21: "FTP", 23: "Telnet", 445: "SMB", 3389: "RDP", 5900: "VNC",
                   135: "MSRPC", 139: "NetBIOS", 512: "rexec", 513: "rlogin",
                   873: "rsync", 2375: "Docker API", 10250: "Kubelet"}
    SEV_RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3}

    sql = ("SELECT a.*, t.value AS target_value FROM assets a "
           "JOIN targets t ON t.id=a.target_id WHERE a.status='active'")
    args: list[Any] = []
    if group_id is not None:
        sql += " AND t.group_id=?"; args.append(group_id)
    if target_id is not None:
        sql += " AND (a.target_id=? OR t.parent_id=?)"; args += [target_id, target_id]
    rows = [row_to_dict(r) for r in conn.execute(sql, args)]

    issues: dict[tuple, dict] = {}

    def add(sev: str, typ: str, host: str):
        e = issues.setdefault((sev, typ), {"severity": sev, "type": typ, "hosts": set()})
        e["hosts"].add(host)

    for a in rows:
        d = a.get("details") or {}
        host, kind = a["target_value"], a["kind"]
        if kind == "takeover":
            add("critical", "Subdomain takeover", host)
        elif kind == "bucket" and d.get("public"):
            add("critical", "Public storage bucket", host)
        elif kind == "vuln":
            add("high", "Known vulnerability (CVE)", host)
        elif kind == "breach":
            if d.get("source") == "dehashed" and d.get("with_credentials"):
                add("critical", "Leaked credentials (with passwords)", host)
            else:
                add("high", "Breach exposure", host)
        elif kind == "lookalike" and d.get("risk") == "high":
            add("high", "Active look-alike domain", host)
        elif kind == "impersonation":
            r = d.get("risk", "low")
            if r == "high":
                add("critical", "Brand impersonation site", host)
            elif r == "medium":
                add("high", "Possible brand impersonation", host)
            else:
                add("medium", "Brand-term domain (unverified)", host)
        elif kind == "cert":
            if d.get("expired"):
                add("high", "Expired TLS certificate", host)
            elif d.get("expiring_soon"):
                add("medium", "TLS certificate expiring soon", host)
            if d.get("weak_protocol") or d.get("weak_sig"):
                add("medium", "Weak TLS configuration", host)
            if d.get("self_signed"):
                add("low", "Self-signed certificate", host)
        elif kind == "email":
            k, st = d.get("kind"), d.get("status")
            if k == "DMARC" and st == "missing":
                add("high", "No DMARC (mail spoofable)", host)
            elif k == "DMARC" and st == "monitor":
                add("medium", "DMARC not enforced (p=none)", host)
            elif k == "SPF" and st == "missing":
                add("medium", "No SPF record", host)
            elif k == "SPF" and st == "weak":
                add("medium", "Permissive SPF (+all)", host)
            elif k == "DNSSEC" and st == "disabled":
                add("low", "DNSSEC disabled", host)
        elif kind == "port":
            p = d.get("port")
            if p in DB_PORTS:
                add("critical", f"Internet-exposed {DB_PORTS[p]} database", host)
            elif p in OTHER_RISKY:
                add("high", f"Exposed {OTHER_RISKY[p]} service", host)
            # anything first seen in the last 24h is a fresh exposure
            if a.get("first_seen") and _within_24h(a["first_seen"]):
                add("medium", "Newly internet-exposed (last 24h)", host)

    out = []
    for e in issues.values():
        hosts = sorted(e["hosts"])
        out.append({"severity": e["severity"], "type": e["type"],
                    "count": len(hosts), "hosts": hosts[:15], "host_total": len(hosts)})
    out.sort(key=lambda x: (SEV_RANK.get(x["severity"], 9), -x["count"]))
    return out


def _within_24h(ts: str) -> bool:
    """True if an ISO timestamp is within the last 24 hours."""
    from datetime import datetime, timezone, timedelta
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - dt) <= timedelta(hours=24)
    except Exception:
        return False


def technology_summary(conn: sqlite3.Connection, target_ids: list[int] | None = None,
                       q: str | None = None, group_id: int | None = None) -> list[dict]:
    """Aggregate distinct technologies across scope: name, versions, host count."""
    sql = ("SELECT a.*, t.value AS target_value FROM assets a "
           "JOIN targets t ON t.id=a.target_id "
           "WHERE a.kind='tech' AND a.status='active'")
    args: list[Any] = []
    if group_id is not None:
        sql += " AND t.group_id=?"
        args.append(group_id)
    if target_ids:
        expanded = set(target_ids)
        expanded |= {r["id"] for r in conn.execute(
            "SELECT id FROM targets WHERE parent_id IN (%s)" %
            ",".join("?" * len(target_ids)), target_ids)}
        sql += " AND a.target_id IN (%s)" % ",".join("?" * len(expanded))
        args.extend(expanded)
    if q:
        like = f"%{q.strip()}%"
        sql += " AND (a.label LIKE ? OR a.details LIKE ?)"
        args.extend([like, like])
    rows = [row_to_dict(r) for r in conn.execute(sql, args)]

    agg: dict[str, dict] = {}
    for a in rows:
        d = a.get("details") or {}
        name = d.get("name") or a["label"]
        e = agg.setdefault(name, {"name": name, "category": d.get("category", ""),
                                  "versions": set(), "targets": set(),
                                  "evidence": set(), "verified": False, "is_new": False})
        if d.get("version"):
            e["versions"].add(d["version"])
        e["targets"].add(a["target_value"])
        for ev in d.get("evidence", []) or []:
            e["evidence"].add(ev)
        if d.get("verified"):
            e["verified"] = True
        if a["is_new"] and not a["acknowledged"]:
            e["is_new"] = True
        if d.get("category") and not e["category"]:
            e["category"] = d["category"]
    out = []
    for e in agg.values():
        out.append({"name": e["name"], "category": e["category"],
                    "versions": sorted(e["versions"]), "count": len(e["targets"]),
                    "targets": sorted(e["targets"]), "evidence": sorted(e["evidence"]),
                    "verified": e["verified"], "is_new": e["is_new"]})
    out.sort(key=lambda x: (-x["count"], x["name"].lower()))
    return out
