"""Rich HTML -> PDF attack-surface report (Layout A "Executive brief"),
rendered with WeasyPrint. Covers the same data dict as report_pdf.build_report_pdf
but with a cover page, table of contents, summary cards, a critical call-out,
and clean per-section tables. Falls back to the fpdf2 generator if WeasyPrint's
native libraries aren't available in the environment.
"""
from __future__ import annotations
import html

from .report_pdf import SECTIONS, _detail, _is_crit, _s

# kinds whose value is a long URL (rendered full-width, wrapped)
_URL_KINDS = {"endpoint", "api", "bucket", "secret"}

_CSS = """
@page { size: A4; margin: 18mm 15mm; @bottom-right { content: counter(page); font-size: 9px; color:#8a94a0; } }
* { box-sizing: border-box; }
body { font-family: 'Helvetica Neue', Arial, sans-serif; color:#11151c; font-size:11px; line-height:1.45; }
h1 { font-size:26px; font-weight:600; margin:0; }
.cover { height: 245mm; display:flex; flex-direction:column; }
.cover .sub { color:#107a6e; font-size:13px; margin-top:6px; letter-spacing:.04em; text-transform:uppercase; }
.cover .meta { color:#5f6b78; font-size:12px; margin-top:14px; line-height:1.8; }
.cover .counts { display:flex; gap:14px; margin-top:34px; }
.cover .cbox { border-radius:10px; padding:18px 22px; min-width:120px; }
.cover .cbox .n { font-size:30px; font-weight:600; }
.cover .cbox .l { font-size:12px; margin-top:2px; }
.cbox.total { background:#f1f4f7; color:#11151c; }
.cbox.crit { background:#fbeaea; color:#a32d2d; }
.cbox.warn { background:#faeeda; color:#854f0b; }
.pagebreak { page-break-before: always; }
.toc h2, .section h2 { font-size:15px; font-weight:600; margin:0 0 8px; }
.toc ul { list-style:none; padding:0; margin:0; }
.toc li { display:flex; justify-content:space-between; padding:5px 0; border-bottom:.5px solid #e6e9ed; font-size:12px; }
.toc li .c { color:#8a94a0; }
.cards { display:flex; flex-wrap:wrap; gap:10px; margin:12px 0 6px; }
.card { background:#f1f4f7; border-radius:8px; padding:10px 14px; min-width:96px; }
.card .l { font-size:11px; color:#5f6b78; }
.card .n { font-size:20px; font-weight:600; }
.callout { background:#fbeaea; border-left:3px solid #e24b4a; color:#a32d2d; padding:9px 13px; font-size:11.5px; border-radius:0 6px 6px 0; margin:14px 0; }
.section { margin-top:20px; }
.section .hdr { display:flex; align-items:center; gap:8px; border-bottom:1.5px solid #d7dbe0; padding-bottom:5px; margin-bottom:6px; }
.section .hdr .cnt { font-size:11px; color:#5f6b78; background:#f1f4f7; padding:1px 9px; border-radius:20px; }
.section .hdr.crit .cnt { color:#a32d2d; background:#fbeaea; }
table { width:100%; border-collapse:collapse; font-size:10.5px; table-layout:fixed; }
th { text-align:left; color:#5f6b78; font-weight:600; padding:5px 7px; border-bottom:.5px solid #d7dbe0; font-size:10px; }
td { padding:5px 7px; border-bottom:.5px solid #eceef1; vertical-align:top; word-break:break-word; overflow-wrap:anywhere; }
td.host { width:26%; }
td.find { width:34%; }
td.det { width:40%; color:#5f6b78; }
td.mono { font-family:'Courier New',monospace; }
.urlrow td.url { width:100%; word-break:break-all; font-family:'Courier New',monospace; color:#185fa5; }
.crit td { color:#a32d2d; }
.pill { display:inline-block; padding:1px 8px; border-radius:20px; font-size:9.5px; }
.pill.crit { background:#fbeaea; color:#a32d2d; }
.pill.warn { background:#faeeda; color:#854f0b; }
.pill.ok { background:#eaf3de; color:#3b6d11; }
.foot { margin-top:26px; color:#8a94a0; font-size:10px; border-top:.5px solid #e6e9ed; padding-top:8px; }
"""


def _esc(v) -> str:
    return html.escape(_s(v))


def _severity_pill(a: dict) -> str:
    d = a.get("details") or {}
    if _is_crit(a):
        return '<span class="pill crit">critical</span>'
    risk = (d.get("risk") or d.get("severity") or "") if isinstance(d, dict) else ""
    if risk in ("high",):
        return '<span class="pill crit">high</span>'
    if risk in ("medium",):
        return '<span class="pill warn">medium</span>'
    return ""


def build_report_html(data: dict) -> str:
    t = data["target"]
    is_group = bool(data.get("group")) and "(group)" in _s(t.get("value", ""))
    title = _esc(data["group"]["name"]) if is_group and data.get("group") else _esc(t.get("value", "target"))
    assets = data.get("assets", [])
    total = data.get("asset_total", len(assets))
    crit = sum(1 for a in assets if _is_crit(a))
    new_count = data.get("new_count", 0)

    by_kind: dict[str, list] = {}
    for a in assets:
        by_kind.setdefault(a["kind"], []).append(a)
    present = [(k, lbl) for k, lbl in SECTIONS if by_kind.get(k)]

    # cover
    meta = [f"Scan mode: {_esc(t.get('scan_mode', 'passive'))}"]
    if data.get("group"):
        meta.append(f"Group: {_esc(data['group'].get('name'))}")
    meta.append(f"Subdomains: {len(data.get('subdomains', []))}")
    meta.append(f"Last scan: {_esc(t.get('last_scan_at') or '-')}")
    meta.append(f"Generated: {_esc(data.get('generated_at'))}")

    cover = f"""<div class="cover">
      <div style="flex:1">
        <div class="sub">Attack surface report</div>
        <h1>{title}</h1>
        <div class="meta">{'<br>'.join(meta)}</div>
        <div class="counts">
          <div class="cbox total"><div class="n">{total}</div><div class="l">total findings</div></div>
          <div class="cbox crit"><div class="n">{crit}</div><div class="l">critical</div></div>
          <div class="cbox warn"><div class="n">{new_count}</div><div class="l">new</div></div>
        </div>
      </div>
    </div>"""

    # table of contents
    toc_items = "".join(
        f'<li><span>{_esc(lbl)}</span><span class="c">{len(by_kind[k])}</span></li>'
        for k, lbl in present)
    toc = f'<div class="pagebreak toc"><h2>Contents</h2><ul>{toc_items}</ul></div>'

    # summary cards + callout
    cards = "".join(
        f'<div class="card"><div class="l">{_esc(lbl)}</div><div class="n">{len(by_kind[k])}</div></div>'
        for k, lbl in present[:8])
    callout = (f'<div class="callout"><b>{crit} critical finding(s)</b> — vulnerabilities, '
               f'public buckets, takeovers or high-risk look-alikes. Review these first.</div>'
               if crit else "")

    # sections
    sec_html = []
    for k, lbl in present:
        rows = by_kind[k]
        rows.sort(key=lambda a: (_s(a.get("target_value", "")), _s(a.get("label", ""))))
        anyc = any(_is_crit(a) for a in rows)
        body = []
        if k in _URL_KINDS:
            body.append('<table>')
            for a in rows:
                cls = " crit" if _is_crit(a) else ""
                det = _detail(a)
                pill = _severity_pill(a)
                body.append(
                    f'<tr class="urlrow{cls}"><td class="url" colspan="1">'
                    f'<span style="color:#5f6b78">{_esc(a.get("target_value",""))}</span> · '
                    f'{_esc(a.get("label",""))} {pill}'
                    f'{("  —  "+_esc(det)) if det else ""}</td></tr>')
            body.append('</table>')
        else:
            body.append('<table><thead><tr><th class="host">Host</th>'
                        '<th class="find">Finding</th><th class="det">Detail</th></tr></thead><tbody>')
            for a in rows:
                cls = " crit" if _is_crit(a) else ""
                body.append(
                    f'<tr class="{cls.strip()}"><td class="host">{_esc(a.get("target_value",""))}</td>'
                    f'<td class="find">{_esc(a.get("label",""))} {_severity_pill(a)}</td>'
                    f'<td class="det">{_esc(_detail(a))}</td></tr>')
            body.append('</tbody></table>')
        sec_html.append(
            f'<div class="section"><div class="hdr{" crit" if anyc else ""}">'
            f'<h2>{_esc(lbl)}</h2><span class="cnt">{len(rows)}</span></div>{"".join(body)}</div>')

    foot = ('<div class="foot">Findings are indicators to review, not confirmed '
            'vulnerabilities.' + (f' Includes {title} and its '
            f'{len(data.get("subdomains", []))} subdomain(s).' if not is_group else '') + '</div>')

    return (f'<!DOCTYPE html><html><head><meta charset="utf-8"><style>{_CSS}</style></head>'
            f'<body>{cover}{toc}<div class="pagebreak"><h2>Summary</h2>'
            f'<div class="cards">{cards}</div>{callout}{"".join(sec_html)}{foot}</div></body></html>')


def build_report_pdf_html(data: dict) -> bytes:
    """Render the rich Layout-A report to PDF via WeasyPrint."""
    from weasyprint import HTML
    return HTML(string=build_report_html(data)).write_pdf()
