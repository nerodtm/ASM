"""Per-group webhook delivery. Auto-detects Slack vs Microsoft Teams from the
URL and sends a clean, informative card — one card per finding. Secrets stay
masked. Delivery is best-effort with a short retry; the last status is stored so
the UI can surface connection failures.
"""
from __future__ import annotations
import asyncio
import httpx

# subscribable event keys (must match the frontend checkboxes)
EVENTS = {
    "new_asset":        "New assets discovered",
    "new_subdomain":    "New subdomains",
    "new_dns":          "New DNS records",
    "new_port":         "Newly discovered open ports",
    "db_port":          "Publicly exposed database ports",
    "exposed_secret":   "Exposed secrets / API keys",
    "critical":         "New critical findings",
    "lookalike":        "New look-alike / impersonation",
    "scan_done":        "Scan completed",
}

# database ports treated as "publicly exposed DB port" when found open
DB_PORTS = {
    3306: "MySQL", 5432: "PostgreSQL", 27017: "MongoDB", 6379: "Redis",
    9200: "Elasticsearch", 9300: "Elasticsearch", 1433: "MSSQL",
    5984: "CouchDB", 11211: "Memcached",
}

_SEV_EMOJI = {"critical": "\U0001F534", "high": "\U0001F534",
              "medium": "\U0001F7E0", "info": "\U0001F535"}


def is_teams(url: str) -> bool:
    u = (url or "").lower()
    return "office.com" in u or "webhook.office" in u or "logic.azure" in u


def is_slack(url: str) -> bool:
    return "hooks.slack.com" in (url or "").lower()


def _slack_card(title: str, fields: list[tuple[str, str]], sev: str) -> dict:
    emoji = _SEV_EMOJI.get(sev, "\U0001F535")
    lines = "\n".join(f"*{k}:* {v}" for k, v in fields)
    return {"blocks": [
        {"type": "section", "text": {"type": "mrkdwn",
         "text": f"{emoji} *{title}*\n{lines}"}},
        {"type": "context", "elements": [
            {"type": "mrkdwn", "text": "Attack Surface Mapper"}]},
    ]}


def _teams_card(title: str, fields: list[tuple[str, str]], sev: str) -> dict:
    color = {"critical": "D93636", "high": "D93636",
             "medium": "E8A317", "info": "2A6FDB"}.get(sev, "2A6FDB")
    return {
        "@type": "MessageCard", "@context": "http://schema.org/extensions",
        "themeColor": color, "summary": title,
        "sections": [{
            "activityTitle": title,
            "facts": [{"name": k, "value": v} for k, v in fields],
            "markdown": True,
        }],
    }


def build_card(url: str, title: str, fields: list[tuple[str, str]], sev: str = "info") -> dict:
    """Pick the right card shape for the destination platform."""
    if is_teams(url):
        return _teams_card(title, fields, sev)
    return _slack_card(title, fields, sev)   # slack shape is a safe generic default


async def deliver(url: str, payload: dict, retries: int = 2) -> tuple[bool, str]:
    """POST with a short retry. Returns (ok, status_text)."""
    last = "no attempt"
    async with httpx.AsyncClient(timeout=10) as client:
        for attempt in range(retries + 1):
            try:
                r = await client.post(url, json=payload)
                if r.status_code < 300:
                    return True, "ok"
                last = f"HTTP {r.status_code}"
            except httpx.HTTPError as e:
                last = type(e).__name__
            if attempt < retries:
                await asyncio.sleep(1.5 * (attempt + 1))
    return False, last


def finding_card(url: str, event_key: str, asset: dict, group_name: str) -> dict:
    """Build a one-finding card from an asset dict."""
    d = asset.get("details") or {}
    if not isinstance(d, dict):
        d = {}
    kind = asset.get("kind", "")
    sev = "critical" if event_key in ("db_port", "exposed_secret", "critical") else \
          ("medium" if event_key == "lookalike" else "info")
    label = EVENTS.get(event_key, event_key)
    value = asset.get("label", "")
    if event_key == "exposed_secret":
        value = f"{d.get('secret_type', 'secret')} — {d.get('masked', '')} (in {d.get('source', '')})"
    fields = [
        ("Type", label),
        ("Finding", value),
        ("Target", asset.get("target_value", "")),
        ("Group", group_name),
    ]
    if d.get("reverse_dns"):
        fields.append(("Reverse DNS", d["reverse_dns"]))
    title = f"{label} — {asset.get('target_value', '')}"
    return build_card(url, title, fields, sev)


def event_for_asset(asset: dict) -> str | None:
    """Map an ingested asset to a webhook event key (or None if not notifiable)."""
    kind = asset.get("kind", "")
    d = asset.get("details") or {}
    d = d if isinstance(d, dict) else {}
    if kind == "port":
        try:
            port = int(str(asset.get("label", "")).split("/")[0].strip())
        except (ValueError, IndexError):
            port = 0
        if port in DB_PORTS:
            return "db_port"
        return "new_port"
    return {
        "secret": "exposed_secret", "subdomain": "new_subdomain",
        "dns": "new_dns", "lookalike": "lookalike", "impersonation": "lookalike",
        "vuln": "critical", "takeover": "critical", "host": "new_asset",
        "bucket": "new_asset", "endpoint": "new_asset", "api": "new_asset",
    }.get(kind)


def sample_card(url: str) -> dict:
    """Payload for the Test-URL button."""
    return build_card(url, "Test alert — Attack Surface Mapper", [
        ("Type", "Publicly exposed database port"),
        ("Finding", "3306/tcp MySQL"),
        ("Target", "demo.example.com"),
        ("Group", "Sample Group"),
    ], "critical")
