"""Server-side PDF report generation.

The dashboard used to build the report in the browser and export it with
window.print(). On domains with thousands of findings that froze the tab — the
browser's print engine can't paginate a single huge table. This builds the PDF
on the server with fpdf2 (pure Python, no headless browser, no system libs) and
streams it as a download, which stays reliable at any size because fpdf2
paginates row by row.
"""
from __future__ import annotations

from fpdf import FPDF

# section order + labels mirror the on-screen report
SECTIONS = [
    ("host", "Hosts / IPs"), ("subdomain", "Subdomains"), ("port", "Open ports & services"),
    ("vuln", "Vulnerabilities"), ("takeover", "Subdomain takeover"),
    ("breach", "Breaches / leaked credentials"), ("cert", "TLS certificates"),
    ("dns", "DNS records"), ("ns", "Name servers"), ("dns_history", "DNS history"),
    ("email", "Email security"), ("waf", "WAF / CDN"), ("idp", "Identity / cloud"),
    ("bucket", "Storage buckets"), ("tech", "Technologies"), ("endpoint", "Endpoints"),
    ("lookalike", "Look-alike domains"), ("impersonation", "Brand impersonation"),
    ("intel", "Threat intel"),
]

INK = (17, 21, 28)
ACCENT = (16, 122, 110)
MUTE = (110, 120, 130)
ALERT = (200, 60, 60)
LINE = (222, 226, 230)

CRIT_KINDS = {"takeover", "vuln", "breach"}


def _s(v) -> str:
    """Coerce to a Latin-1-safe string (core fdpf fonts are Latin-1)."""
    if v is None:
        return ""
    return str(v).encode("latin-1", "replace").decode("latin-1")


def _detail(a: dict) -> str:
    d = a.get("details") or {}
    if not isinstance(d, dict):
        return ""
    for k in ("mode", "risk", "severity", "issuer", "status", "evidence", "confidence",
              "verified_status", "tenant_id", "account_id", "cve", "name"):
        if d.get(k):
            v = d[k]
            if isinstance(v, list):
                v = ", ".join(map(str, v[:3]))
            return _s(v)[:80]
    return ""


def _is_crit(a: dict) -> bool:
    d = a.get("details") or {}
    return (a["kind"] in CRIT_KINDS
            or (a["kind"] == "bucket" and d.get("public"))
            or (a["kind"] == "cert" and d.get("expired"))
            or (a["kind"] in ("impersonation", "lookalike") and d.get("risk") == "high"))


class _PDF(FPDF):
    def __init__(self, domain: str):
        super().__init__(orientation="P", unit="mm", format="A4")
        self.domain = domain
        self.set_auto_page_break(auto=True, margin=15)
        self.set_title(f"{domain} attack surface report")

    def header(self):
        if self.page_no() == 1:
            return
        self.set_font("Helvetica", "", 8)
        self.set_text_color(*MUTE)
        self.cell(0, 6, _s(f"{self.domain} — attack surface report"), align="L")
        self.ln(8)

    def footer(self):
        self.set_y(-12)
        self.set_font("Helvetica", "", 8)
        self.set_text_color(*MUTE)
        self.cell(0, 6, f"Page {self.page_no()}", align="C")


def build_report_pdf(data: dict) -> bytes:
    t = data["target"]
    domain = _s(t.get("value", "target"))
    pdf = _PDF(domain)
    pdf.add_page()

    # title
    pdf.set_font("Helvetica", "B", 20)
    pdf.set_text_color(*INK)
    pdf.cell(0, 12, domain, new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 11)
    pdf.set_text_color(*ACCENT)
    pdf.cell(0, 7, "Attack surface report", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(2)

    # metadata
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(*MUTE)
    meta = [
        f"Scan mode: {t.get('scan_mode', 'passive')}",
        f"Last scan: {_s(t.get('last_scan_at') or '-')}",
        f"Status: {_s(t.get('last_status') or '-')}",
    ]
    if data.get("group"):
        meta.append(f"Group: {_s(data['group'].get('name'))}")
    meta.append(f"Subdomains: {len(data.get('subdomains', []))}")
    meta.append(f"Generated: {_s(data.get('generated_at'))}")
    for m in meta:
        pdf.cell(0, 5, _s(m), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(2)

    # summary line
    assets = data.get("assets", [])
    crit = sum(1 for a in assets if _is_crit(a))
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_text_color(*INK)
    pdf.cell(0, 6, _s(f"{data.get('asset_total', len(assets))} total findings   "
                      f"{data.get('new_count', 0)} new   {crit} critical"),
             new_x="LMARGIN", new_y="NEXT")
    if crit:
        pdf.set_text_color(*ALERT)
        pdf.cell(0, 5, _s(f"{crit} critical finding(s): vulnerabilities, breaches, "
                          f"takeovers or public buckets — review first."),
                 new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)

    # group assets by kind
    by_kind: dict[str, list] = {}
    for a in assets:
        by_kind.setdefault(a["kind"], []).append(a)

    # column widths (A4 usable width ~180mm)
    W_HOST, W_FIND, W_DETAIL, W_FLAG = 45, 60, 65, 10

    for kind, label in SECTIONS:
        rows = by_kind.get(kind)
        if not rows:
            continue
        rows.sort(key=lambda a: (_s(a.get("target_value", "")), _s(a.get("label", ""))))

        # section header (keep with at least one row)
        if pdf.will_page_break(16):
            pdf.add_page()
        pdf.set_font("Helvetica", "B", 12)
        pdf.set_text_color(*INK)
        pdf.cell(0, 8, _s(f"{label}  ({len(rows)})"), new_x="LMARGIN", new_y="NEXT")

        # table header
        pdf.set_font("Helvetica", "B", 8)
        pdf.set_text_color(*MUTE)
        pdf.set_fill_color(245, 246, 248)
        pdf.cell(W_HOST, 6, "Host", border=0, fill=True)
        pdf.cell(W_FIND, 6, "Finding", border=0, fill=True)
        pdf.cell(W_DETAIL, 6, "Detail", border=0, fill=True)
        pdf.cell(W_FLAG, 6, "", border=0, fill=True, new_x="LMARGIN", new_y="NEXT")

        pdf.set_font("Helvetica", "", 8)
        for a in rows:
            host = _s(a.get("target_value", ""))[:34]
            find = _s(a.get("label", ""))[:46]
            det = _detail(a)[:52]
            newf = a.get("is_new") and not a.get("acknowledged")
            crit_row = _is_crit(a)
            flag = "!" if crit_row else ("N" if newf else "")
            pdf.set_text_color(*(ALERT if crit_row else INK))
            pdf.cell(W_HOST, 5, host)
            pdf.cell(W_FIND, 5, find)
            pdf.set_text_color(*MUTE)
            pdf.cell(W_DETAIL, 5, det)
            pdf.set_text_color(*(ALERT if crit_row else ACCENT))
            pdf.cell(W_FLAG, 5, flag, new_x="LMARGIN", new_y="NEXT")
        pdf.ln(3)

    if not by_kind:
        pdf.set_font("Helvetica", "", 10)
        pdf.set_text_color(*MUTE)
        pdf.cell(0, 6, "No findings recorded yet - run a scan.", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(4)
    pdf.set_font("Helvetica", "I", 8)
    pdf.set_text_color(*MUTE)
    pdf.multi_cell(0, 4, _s(
        "Findings are indicators to review, not confirmed vulnerabilities. "
        f"Includes {domain} and its {len(data.get('subdomains', []))} subdomain(s)."))

    out = pdf.output()
    return bytes(out)
