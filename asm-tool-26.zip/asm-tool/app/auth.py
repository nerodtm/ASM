"""Authentication primitives: password hashing, password policy, session tokens.

Uses only the Python standard library (PBKDF2-HMAC-SHA256) so there are no extra
dependencies and no native build steps. Password hashes are self-describing
("pbkdf2_sha256$iters$salt$hash") so the work factor can be raised later without
breaking existing hashes.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import re
import secrets

# --- tunables (env-overridable) --------------------------------------------
PW_MIN_LEN = max(8, int(os.environ.get("ASM_PW_MIN_LEN", "10")))
PBKDF2_ITERS = int(os.environ.get("ASM_PBKDF2_ITERS", "210000"))
SESSION_HOURS = max(1, int(os.environ.get("ASM_SESSION_HOURS", "2")))  # hours of inactivity
COOKIE_NAME = "asm_session"
COOKIE_SECURE = os.environ.get("ASM_COOKIE_SECURE", "0") in ("1", "true", "yes")


def hash_password(password: str) -> str:
    """Return a self-describing PBKDF2 hash string."""
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERS)
    return f"pbkdf2_sha256${PBKDF2_ITERS}${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    """Constant-time verification of a password against a stored hash."""
    try:
        algo, iters, salt_hex, hash_hex = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iters))
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False


def password_policy_error(pw: str) -> str | None:
    """Return a human-readable reason a password is unacceptable, else None."""
    if pw is None or len(pw) < PW_MIN_LEN:
        return f"Password must be at least {PW_MIN_LEN} characters long."
    if len(pw) > 200:
        return "Password is too long (max 200 characters)."
    if not re.search(r"[a-z]", pw):
        return "Password must include a lowercase letter."
    if not re.search(r"[A-Z]", pw):
        return "Password must include an uppercase letter."
    if not re.search(r"[0-9]", pw):
        return "Password must include a digit."
    return None


def policy_description() -> str:
    return (f"At least {PW_MIN_LEN} characters, including an uppercase letter, "
            f"a lowercase letter, and a digit.")


def valid_username(name: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9_.\-]{3,40}", name or ""))


def valid_email(addr: str) -> bool:
    return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", (addr or "").strip()))


def email_domain(addr: str) -> str:
    return addr.rsplit("@", 1)[1].lower() if "@" in (addr or "") else ""


def new_token() -> str:
    return secrets.token_urlsafe(32)


# --- TOTP two-factor auth (Google Authenticator) ---
import pyotp
import json as _json

ISSUER = os.environ.get("ASM_TOTP_ISSUER", "Attack Surface Mapper")


def new_totp_secret() -> str:
    return pyotp.random_base32()


def totp_uri(secret: str, username: str) -> str:
    """otpauth:// provisioning URI to encode into the QR code."""
    return pyotp.TOTP(secret).provisioning_uri(name=username, issuer_name=ISSUER)


def verify_totp(secret: str, code: str) -> bool:
    if not secret or not code:
        return False
    try:
        return pyotp.TOTP(secret).verify(str(code).strip().replace(" ", ""), valid_window=1)
    except Exception:
        return False


def gen_backup_codes(n: int = 10) -> list[str]:
    return ["-".join(secrets.token_hex(2) for _ in range(2)) for _ in range(n)]


def hash_backup_codes(codes: list[str]) -> str:
    return _json.dumps([hash_password(c) for c in codes])


def check_backup_code(stored_json: str, code: str) -> tuple[bool, str | None]:
    """Return (ok, new_stored_json_with_that_code_removed). One-time use."""
    if not stored_json:
        return False, None
    try:
        hashes = _json.loads(stored_json)
    except Exception:
        return False, None
    code = (code or "").strip()
    for h in hashes:
        if verify_password(code, h):
            hashes.remove(h)
            return True, _json.dumps(hashes)
    return False, None
