"""Scanner worker — the separate container that does the actual scanning.

Run in its own container with:  python -m app.worker

It has two jobs:
  1. Consume the scan-job queue: claim queued jobs and run each scan, up to
     ASM_SCAN_CONCURRENCY at a time.
  2. Run the automatic schedule (weekly by default): enqueue every domain +
     subdomain on cadence.

The API container (ASM_SCANNER=worker) only enqueues jobs and serves the
dashboard, so scanning never competes with the UI. Both share the same
database. Set ASM_SCANNER=worker on BOTH the API and this worker.
"""
from __future__ import annotations

import asyncio
import os

from . import db, scanner  # noqa: F401  (scanner import validates env early)
from .main import scan_target, scheduler_loop, SCAN_CONCURRENCY

POLL_SECONDS = float(os.environ.get("ASM_WORKER_POLL_SECONDS", "2"))
_sem = asyncio.Semaphore(SCAN_CONCURRENCY)


async def _run_job(job: dict) -> None:
    async with _sem:
        conn = db.connect()
        try:
            result = await scan_target(job["target_id"])
            status = "error" if (isinstance(result, dict) and result.get("error")) else "done"
            detail = str(result.get("error", "")) if isinstance(result, dict) else ""
            db.finish_job(conn, job["id"], status, detail)
        except Exception as exc:  # never let one bad job kill the worker
            try:
                db.finish_job(conn, job["id"], "error", str(exc))
            except Exception:
                pass
        finally:
            conn.close()


async def consumer() -> None:
    """Claim and run queued jobs. Bounded concurrency via the semaphore."""
    inflight: set[asyncio.Task] = set()
    while True:
        # keep the pipeline full up to the concurrency limit
        launched = False
        while len(inflight) < SCAN_CONCURRENCY:
            conn = db.connect()
            try:
                job = db.claim_next_job(conn)
            finally:
                conn.close()
            if not job:
                break
            t = asyncio.create_task(_run_job(job))
            inflight.add(t)
            t.add_done_callback(inflight.discard)
            launched = True
        if not launched:
            await asyncio.sleep(POLL_SECONDS)
        else:
            await asyncio.sleep(0.1)


async def janitor() -> None:
    """Periodically trim finished jobs so the queue table stays small."""
    while True:
        await asyncio.sleep(3600)
        try:
            conn = db.connect()
            db.prune_jobs(conn, int(os.environ.get("ASM_JOB_KEEP_DAYS", "7")))
            conn.close()
        except Exception:
            pass


async def main() -> None:
    db.init_db()
    print(f"[ASM worker] started — concurrency={SCAN_CONCURRENCY}, poll={POLL_SECONDS}s", flush=True)
    # consumer + the shared weekly scheduler (which enqueues in worker mode) + janitor
    await asyncio.gather(consumer(), scheduler_loop(), janitor())


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
