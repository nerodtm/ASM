"""Attack Surface Mapper — a lightweight, self-hostable ASM tool."""
__version__ = "1.0.0"
